//
//  Filter.cpp
//  Lab 5-6
//
//  Created by Adrian-Paul Florea on 4/5/18.
//  Copyright © 2018 Adrian-Paul Florea. All rights reserved.
//

#include "Filter.h"
