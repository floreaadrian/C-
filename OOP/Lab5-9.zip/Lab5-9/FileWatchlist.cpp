//
//  FileWatchlist.cpp
//  Lab5-6STL
//
//  Created by Adrian-Paul Florea on 4/23/18.
//  Copyright © 2018 Adrian-Paul Florea. All rights reserved.
//

#include "FileWatchlist.h"

FileWatchlist::FileWatchlist(const std::string& filename)
{
    this->filename = filename;
}
