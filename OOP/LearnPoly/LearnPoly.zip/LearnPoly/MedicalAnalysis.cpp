//
//  MedicalAnalysis.cpp
//  LearnPoly
//
//  Created by Adrian-Paul Florea on 5/16/18.
//  Copyright © 2018 Adrian-Paul Florea. All rights reserved.
//

#include "MedicalAnalysis.h"

Medical::Medical(const std::string& d){
    this->date=d;
}
